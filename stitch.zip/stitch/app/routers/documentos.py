"""Endpoints de documentos.

Mapean directamente a la interfaz Stitch:
  - GET  /documentos              -> tabla principal + chips de filtro + paginación
  - GET  /documentos/buscar       -> campo "Buscar por nombre, autor o folio"
  - POST /documentos              -> botón "Nuevo Documento" (sube a MinIO)
  - GET  /documentos/{folio}/url  -> botón "Descargar" (URL prefirmada)
  - DELETE /documentos/{folio}    -> botón "Eliminar" (soft delete)
"""
from __future__ import annotations

import io
import re
from typing import Literal

from fastapi import APIRouter, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import StreamingResponse

import cache
import storage
from database import get_cursor
from schemas import DocumentoOut, Estado, PaginaDocumentos, Prioridad

router = APIRouter(prefix="/documentos", tags=["documentos"])

# Mapa chip de la UI -> vista SQL
VISTA_POR_FILTRO = {
    "todos": "v_documentos",
    "pendientes": "v_documentos_pendientes",
    "completados": "v_documentos_completados",
    "recientes": "v_documentos_recientes",
    "prioritarios": "v_documentos_prioritarios",
}

EXT_A_TIPO = {"pdf": "pdf", "xlsx": "xlsx", "docx": "docx",
              "csv": "csv", "pptx": "pptx"}

# Tipo MIME por extensión: necesario para que el navegador PREVISUALICE
# (en vez de descargar) cuando se abre con el "ojito". PDF e imágenes se
# muestran inline; lo demás el navegador lo bajará igual.
MIME_POR_EXT = {
    "pdf": "application/pdf",
    "png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
    "gif": "image/gif", "webp": "image/webp", "svg": "image/svg+xml",
    "txt": "text/plain; charset=utf-8", "csv": "text/csv; charset=utf-8",
    "json": "application/json",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
}


def _mime(ruta: str) -> str:
    ext = ruta.rsplit(".", 1)[-1].lower() if "." in ruta else ""
    return MIME_POR_EXT.get(ext, "application/octet-stream")


def _iniciales(nombre: str) -> str:
    """Genera iniciales (máx. 8) a partir del nombre del autor."""
    partes = [p for p in re.split(r"\s+", nombre.strip()) if p]
    if len(partes) >= 2:
        ini = partes[0][0] + partes[1][0]
    elif partes:
        ini = partes[0][:2]
    else:
        ini = "?"
    return ini.upper()[:8]


@router.get("", response_model=PaginaDocumentos)
def listar(
    filtro: Literal["todos", "pendientes", "completados",
                    "recientes", "prioritarios"] = "todos",
    pagina: int = Query(1, ge=1),
    por_pagina: int = Query(4, ge=1, le=100),
):
    """Tabla principal con filtro por chip y paginación."""
    cache_key = f"list:{filtro}:{pagina}:{por_pagina}"
    if (hit := cache.get_json(cache_key)) is not None:
        return hit

    vista = VISTA_POR_FILTRO[filtro]
    offset = (pagina - 1) * por_pagina

    with get_cursor() as cur:
        cur.execute(f"SELECT count(*) AS total FROM {vista}")
        total = cur.fetchone()["total"]

        cur.execute(
            f"""
            SELECT * FROM {vista}
            ORDER BY fecha_creacion DESC
            LIMIT %s OFFSET %s
            """,
            (por_pagina, offset),
        )
        items = cur.fetchall()

    resultado = PaginaDocumentos(
        items=items, total=total, pagina=pagina, por_pagina=por_pagina
    ).model_dump()
    cache.set_json(cache_key, resultado)
    return resultado


@router.get("/buscar", response_model=list[DocumentoOut])
def buscar(q: str = Query(..., min_length=1)):
    """Búsqueda libre por nombre, folio o autor (usa los índices trigram)."""
    cache_key = f"search:{q.lower()}"
    if (hit := cache.get_json(cache_key)) is not None:
        return hit

    patron = f"%{q}%"
    with get_cursor() as cur:
        cur.execute(
            """
            SELECT * FROM v_documentos
            WHERE nombre ILIKE %(p)s
               OR folio  ILIKE %(p)s
               OR autor_nombre ILIKE %(p)s
            ORDER BY fecha_creacion DESC
            LIMIT 50
            """,
            {"p": patron},
        )
        items = cur.fetchall()

    cache.set_json(cache_key, items)
    return items


@router.post("", response_model=DocumentoOut, status_code=201)
async def crear(
    nombre: str = Form(..., min_length=1),       # Título del documento (obligatorio)
    autor_nombre: str = Form(...),               # Nombre del autor (texto libre)
    descripcion: str = Form(""),                 # Objetivo / sistema / reporte / etc.
    estado: Estado = Form(Estado.pendiente),
    prioridad: Prioridad = Form(Prioridad.normal),
    archivo: UploadFile = File(...),
):
    """Sube un documento: el binario va a MinIO, los metadatos a Postgres.

    El usuario escribe el TÍTULO a mano (debe llevar guiones bajos, no espacios)
    y el NOMBRE DEL AUTOR como texto libre; si el autor no existe se crea.
    La extensión y el tipo se deducen del archivo subido.
    """
    titulo = nombre.strip()
    if not titulo:
        raise HTTPException(422, "El título es obligatorio")
    # El título debe seguir la convención con guiones bajos (sin espacios).
    if " " in titulo or "_" not in titulo:
        raise HTTPException(
            422,
            "El título debe usar guiones bajos en vez de espacios y llevar el "
            "nombre completo (ej. Reporte_Mensual_Ventas), no una sola palabra.",
        )

    autor = autor_nombre.strip()
    if not autor:
        raise HTTPException(422, "El nombre del autor es obligatorio")

    nombre_archivo = archivo.filename or "sin_nombre"
    ext = nombre_archivo.rsplit(".", 1)[-1].lower() if "." in nombre_archivo else ""
    tipo = EXT_A_TIPO.get(ext, "otro")
    contenido = await archivo.read()

    with get_cursor() as cur:
        # Resuelve el autor por nombre: si ya existe lo reutiliza, si no lo crea.
        cur.execute(
            "SELECT id FROM usuarios WHERE lower(nombre) = lower(%s) AND activo "
            "ORDER BY id LIMIT 1",
            (autor,),
        )
        fila = cur.fetchone()
        if fila:
            autor_id = fila["id"]
        else:
            cur.execute(
                "INSERT INTO usuarios (nombre, iniciales) VALUES (%s, %s) "
                "RETURNING id",
                (autor, _iniciales(autor)),
            )
            autor_id = cur.fetchone()["id"]

        # Genera el siguiente folio ST-#### de forma atómica.
        cur.execute(
            """
            SELECT coalesce(max(substring(folio from 4)::int), 0) + 1 AS siguiente
            FROM documentos
            """
        )
        folio = f"ST-{cur.fetchone()['siguiente']:04d}"
        # La object key conserva el nombre real del archivo (con su extensión).
        object_key = f"{folio}/{nombre_archivo}"

        tamano = storage.subir(
            object_key, contenido,
            archivo.content_type or "application/octet-stream",
        )

        cur.execute(
            """
            INSERT INTO documentos
                (folio, nombre, descripcion, tipo, estado, prioridad,
                 autor_id, tamano_bytes, ruta_archivo)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
            RETURNING id
            """,
            (folio, titulo, descripcion.strip() or None, tipo,
             estado.value, prioridad.value, autor_id, tamano, object_key),
        )
        nuevo_id = cur.fetchone()["id"]

        cur.execute(
            "INSERT INTO historial_documentos (documento_id, usuario_id, accion) "
            "VALUES (%s, %s, 'creado')",
            (nuevo_id, autor_id),
        )

        cur.execute("SELECT * FROM v_documentos WHERE id = %s", (nuevo_id,))
        doc = cur.fetchone()

    cache.invalidate_all()
    return doc


@router.get("/{folio}/url")
def url_descarga(folio: str):
    """Devuelve una URL prefirmada temporal para descargar (botón Descargar)."""
    if not re.match(r"^ST-\d{3,}$", folio):
        raise HTTPException(400, "Folio inválido")

    with get_cursor() as cur:
        cur.execute(
            "SELECT ruta_archivo FROM v_documentos WHERE folio = %s", (folio,)
        )
        row = cur.fetchone()

    if not row:
        raise HTTPException(404, "Documento no encontrado")
    if not row["ruta_archivo"]:
        raise HTTPException(409, "El documento no tiene archivo asociado")

    return {"url": storage.url_descarga(row["ruta_archivo"])}


@router.get("/{folio}/descargar")
def descargar(folio: str, inline: bool = Query(False)):
    """Transmite el archivo a través de la API (funciona desde el navegador).

    A diferencia de /url, no devuelve una URL de MinIO sino el binario mismo,
    así no importa que MinIO solo sea accesible dentro de la red de Docker.

    Con ?inline=1 se sirve con el tipo MIME real para que el navegador lo
    PREVISUALICE (el "ojito"); sin él, fuerza la descarga (botón Descargar).
    """
    if not re.match(r"^ST-\d{3,}$", folio):
        raise HTTPException(400, "Folio inválido")

    with get_cursor() as cur:
        cur.execute(
            "SELECT id, nombre, ruta_archivo FROM v_documentos WHERE folio = %s",
            (folio,),
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Documento no encontrado")
        if not row["ruta_archivo"]:
            raise HTTPException(409, "Este documento no tiene archivo asociado")
        accion = "visto" if inline else "descargado"
        cur.execute(
            "INSERT INTO historial_documentos (documento_id, accion) "
            "VALUES (%s, %s)",
            (row["id"], accion),
        )

    data = storage.obtener(row["ruta_archivo"])
    # Nombre de archivo real (con extensión) tomado de la object key.
    filename = row["ruta_archivo"].split("/")[-1]
    disposition = "inline" if inline else "attachment"
    media = _mime(row["ruta_archivo"]) if inline else "application/octet-stream"
    return StreamingResponse(
        io.BytesIO(data),
        media_type=media,
        headers={"Content-Disposition": f'{disposition}; filename="{filename}"'},
    )


@router.delete("/{folio}", status_code=204)
def eliminar(folio: str):
    """Soft delete: marca eliminado_en, no borra la fila (botón Eliminar)."""
    with get_cursor() as cur:
        cur.execute(
            """
            UPDATE documentos SET eliminado_en = now()
            WHERE folio = %s AND eliminado_en IS NULL
            RETURNING id
            """,
            (folio,),
        )
        row = cur.fetchone()
        if not row:
            raise HTTPException(404, "Documento no encontrado o ya eliminado")
        cur.execute(
            "INSERT INTO historial_documentos (documento_id, accion) "
            "VALUES (%s, 'eliminado')",
            (row["id"],),
        )

    cache.invalidate_all()
